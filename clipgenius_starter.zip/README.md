# ClipGenius Starter Repo
- Frontend: Next.js starter
- Backend: Node.js starter
- AI: Whisper placeholder
- Deployment: Render (backend), Vercel (frontend)